Early-Post-Web

1. cd early-post-web 
2. Install all the packages using `npm i`
3. Setup .env file
4. Make sure the early-post-api is running
5. Run the server using `npm start`
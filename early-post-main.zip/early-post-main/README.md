**Newspaper Delivery Management System**

**Computer Engineering (SEM-III) Mini-Project**

**Early Post** is a web application that let users create accounts, purchase newspapers, place orders and ask queries.
Admin can then monitor the orders, assign delivery agents and resolve the queries.

**Tech Used:**

Frontend

1. React
2. Chakra-UI
3. Formik Yup
4. Axios 

Backend

1. ExpressJS 
2. Typescript
3. TypeORM
4. PostgreSQL
5. Redis
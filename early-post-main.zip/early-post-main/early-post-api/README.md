Early-Post-API

The project uses TypeScript, ExpressJS, TypeORM, Redis. The database required is postgreSQL.

1. cd early-post-api.
2. Configure .env by referring to example file provided.
3. Install packages using `npm install`
4. Run Typescript using `npm run watch`
5. Start server using `npm run dev`